%% Test Script
close all;
clear;
clc;

% "undulating" path
s1 = [0      20      40   150];
k1 = [1/20   -1/20   0    0];
path = 0;

% simulation time
dT = 0.005;
t_final = 10;
t_s = 0:dT:t_final;
N = length(t_s);


% allocate space for simulation data
ux_mps = zeros(N,1);
uy_mps = zeros(N,1);
r_radps = zeros(N,1);
deltaPsi_rad = zeros(N,1);
s_m = zeros(N,1);
e_m = zeros(N,1);

modeSelector = 1;

[ delta_rad, Fx_N ] = me227_controller( s_m, e_m, deltaPsi_rad, ux_mps,...
    uy_mps, r_radps, modeSelector, path );